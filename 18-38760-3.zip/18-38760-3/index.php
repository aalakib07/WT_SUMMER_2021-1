<?php 
     header("location: views/page-1.php");
?>

